﻿namespace RobotRoverTask
{
    internal interface IRoverPosition
    {
        bool Move(string rovermoves);
        void SetInitialPosition(int xPoint, int yPoint, string dPoint);
        string GetFinalRoverPostion();
    }
}