﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotRoverTask
{
    class Program
    {
        static void Main(string[] args)
        {
            //[x y d]
            int X, Y;
            string D;

            Console.WriteLine($"Enter rover initial position (e.g.0 0 N):");
            var initialPosition = Console.ReadLine().Trim().Split(' ').ToList();

            RoverPosition position = new RoverPosition();

            if (initialPosition.Count() == 3)
            {
                X = Convert.ToInt32(initialPosition[0]);
                Y = Convert.ToInt32(initialPosition[1]);
                D = Convert.ToString(initialPosition[2]);
                position.SetInitialPosition(X, Y, D);
            }else
            {
                Console.WriteLine($"Invalid characters entered;Rover set to default position.");
            }

            Console.WriteLine($"Enter rover new position (e.g.L2R2):");
            string rovermoves = Console.ReadLine().Trim();
            position.Move(rovermoves);

            string response = string.Empty;
            do
            {
                Console.WriteLine($"Enter M to move further or C to complete mission : ");
                response = Console.ReadLine();

                if (response == "M")
                {
                    Console.WriteLine($"Enter rover new position (e.g.L2R2):");
                    rovermoves = Console.ReadLine().Trim();
                    position.Move(rovermoves);
                }
                else
                {
                    Console.WriteLine($"Final Rover Position : [ {position.GetFinalRoverPostion()} ]");
                }
            } while (response == "M");

            Console.ReadLine();
        }
    }
}
