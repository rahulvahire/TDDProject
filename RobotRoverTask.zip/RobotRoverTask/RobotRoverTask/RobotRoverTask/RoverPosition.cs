﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RobotRoverTask
{
    public class RoverPosition : IRoverPosition
    {

        public int X { get; set; }
        public int Y { get; set; }
        public Directions Direction { get; set; }

        public RoverPosition()
        {
            X = Y = 0;
            Direction = Directions.N;
        }

        public void SetInitialPosition(int xPoint, int yPoint, string dPoint)
        {
            X = xPoint;
            Y = yPoint;
            Direction = (Directions)Enum.Parse(typeof(Directions), dPoint);
        }

        public bool Move(string rovermoves)
        {
            bool MoveSucessful = false;
            try
            {
                if (rovermoves.Length % 2 == 0)
                {
                    int totalMoves = rovermoves.Length / 2;

                    for (int i = 0; i < totalMoves; i++)
                    {
                        var movePoints = rovermoves.Select(x => new string(x, 1)).ToArray().Skip(i * 2).Take(2).ToList();

                        char direction = Convert.ToChar(movePoints.First());
                        int stepCounts = Convert.ToInt32(movePoints.Skip(1).First());

                        switch (direction)
                        {
                            case 'L':
                                this.Rotate90Left();
                                break;
                            case 'R':
                                this.Rotate90Right();
                                break;
                            default:
                                Console.WriteLine($"Invalid direction character : {direction}");
                                break;
                        }

                        for (int j = 0; j < stepCounts; j++)
                        {
                            MoveInSameDirection();
                        }
                        MoveSucessful = true;
                    }
                    
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Invalid direction characters entered : {rovermoves}");
            }
            return MoveSucessful;
        }

        public string GetFinalRoverPostion()
        {

            return string.Join(",", this.X, this.Y, this.Direction);
        }

        private void Rotate90Left()
        {
            switch (this.Direction)
            {
                case Directions.N:
                    this.Direction = Directions.W;
                    break;
                case Directions.S:
                    this.Direction = Directions.E;
                    break;
                case Directions.E:
                    this.Direction = Directions.N;
                    break;
                case Directions.W:
                    this.Direction = Directions.S;
                    break;
                default:
                    break;
            }
        }

        private void Rotate90Right()
        {
            switch (this.Direction)
            {
                case Directions.N:
                    this.Direction = Directions.E;
                    break;
                case Directions.S:
                    this.Direction = Directions.W;
                    break;
                case Directions.E:
                    this.Direction = Directions.S;
                    break;
                case Directions.W:
                    this.Direction = Directions.N;
                    break;
                default:
                    break;
            }
        }

        private void MoveInSameDirection()
        {
            switch (this.Direction)
            {
                case Directions.N:
                    this.Y += 1;
                    break;
                case Directions.S:
                    this.Y -= 1;
                    break;
                case Directions.E:
                    this.X += 1;
                    break;
                case Directions.W:
                    this.X -= 1;
                    break;
                default:
                    break;
            }
        }


    }
}