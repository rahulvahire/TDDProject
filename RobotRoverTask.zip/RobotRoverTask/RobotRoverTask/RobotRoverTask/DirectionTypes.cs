﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotRoverTask
{
    public enum Directions
    {
        N = 1, //North
        S = 2, //South
        E = 3, //East
        W = 4   //West
    }
}
