﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RobotRoverTask.Test
{
    [TestClass]
    public class WhenMovingRover
    {
        [TestMethod]
        public void ValidCommandRoverMovementSuccessful()
        {
            RoverPosition position = new RoverPosition()
            {
                X = 0,
                Y = 0,
                Direction = Directions.N
            };

            position.SetInitialPosition(1, 1, "S");
            position.Move("L2R2");
            position.Move("L3R3R6L1R1");
            
            string ActualResult = position.GetFinalRoverPostion();
            string ExpectedResult = "-1,-5,W";
            Assert.AreEqual(ActualResult, ExpectedResult);           
        }

        [TestMethod]
        public void ImpermissibleCommandRoverMovementfallOff()
        {
            RoverPosition position = new RoverPosition()
            {
                X = 0,
                Y = 0,
                Direction = Directions.N
            };

            position.SetInitialPosition(1, 1, "S");            
            bool IsSuccess = position.Move("xfdysa");            
            Assert.AreNotEqual(true, IsSuccess);

            string ActualResult = position.GetFinalRoverPostion();
            string ExpectedResult = "1,1,S";
            Assert.AreEqual(ActualResult, ExpectedResult);
        }

    }
}
